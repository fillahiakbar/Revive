<?php

namespace App\Http\Controllers;

use App\Models\AnimeLink;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Cache;

class AnimeDetailController extends Controller
{
    public function show($mal_id)
    {
        $animeLink = AnimeLink::with([
                'types',
                'batches' => fn ($q) => $q->has('batchLinks')->orderByDesc('created_at'),
                'batches.batchLinks',
                'comments' => fn ($q) => $q->latest(),
                'comments.user',
                'relatedGroup.animeLinks.types',
            ])
            ->where('mal_id', $mal_id)
            ->first();

        if (!$animeLink) {
            return redirect()->route('cartoon.detail', $mal_id);
        }

        $animeLink->incrementQuietly('click_count');

        try {
            $today = now()->toDateString();

            $visit = \App\Models\AnimeVisit::firstOrCreate(
                ['anime_link_id' => $animeLink->id, 'visited_date' => $today],
                ['count' => 0]
            );

            $visit->increment('count');
        } catch (\Throwable $e) {
            Log::warning('Failed to increment anime visit: '.$e->getMessage(), [
                'anime_link_id' => $animeLink->id
            ]);
        }

        if (!$animeLink->mal_score || !$animeLink->imdb_score) {
            $this->updateScoresFromApi($animeLink);
        }

        $downloadLinks = $animeLink->batches->flatMap->batchLinks;
        $fromDatabase  = true;

        $jikanData = Cache::remember("jikan_data_{$mal_id}", now()->addHours(6), function () use ($mal_id) {
            try {
                $respFull = Http::timeout(15)->get("https://api.jikan.moe/v4/anime/{$mal_id}/full");
                if ($respFull->successful()) {
                    return $respFull->json('data') ?? [];
                }

                $respLite = Http::timeout(15)->get("https://api.jikan.moe/v4/anime/{$mal_id}");
                if ($respLite->successful()) {
                    return $respLite->json('data') ?? [];
                }
            } catch (\Exception $e) {
                Log::error("Jikan exception for MAL ID {$mal_id}: ".$e->getMessage());
            }

            return [];
        });

        $imdbId = $animeLink->imdb_id ?? $this->extractImdbIdFromJikan($jikanData);

        $omdbData = [];
        if ($imdbId) {
            $omdbData = Cache::remember("omdb_data_{$imdbId}", now()->addDays(7), function () use ($imdbId) {
                try {
                    $response = Http::timeout(15)->get(config('services.omdb.url'), [
                        'apikey' => config('services.omdb.key'),
                        'i'      => $imdbId,
                    ]);

                    if ($response->successful()) {
                        return $response->json();
                    }
                } catch (\Exception $e) {
                    Log::error("OMDb API exception for IMDb ID {$imdbId}: ".$e->getMessage());
                }

                return [];
            });
        }

        $episodes = $animeLink->episodes;
        if (empty($episodes)) {
            $episodes = $jikanData['episodes'] ?? null;
            if (!empty($episodes)) {
                $animeLink->episodes = $episodes;
                $animeLink->saveQuietly();
            }
        }

        $rawGenres = $animeLink->genres ?: ($jikanData['genres'] ?? []);
        $genres    = $this->normalizeGenres($rawGenres);

        if (!empty($jikanData)) {
            $fromDatabase = false;
        }

        $animeData = [
            'mal_id'         => $animeLink->mal_id,
            'title'          => $animeLink->title         ?? ($jikanData['title'] ?? null),
            'title_english'  => $animeLink->title_english ?? ($jikanData['title_english'] ?? null),
            'title_japanese' => $jikanData['title_japanese'] ?? null,
            'poster'         => $animeLink->poster        ?? ($jikanData['images']['jpg']['large_image_url'] ?? null),
            'synopsis'       => $animeLink->synopsis      ?? ($jikanData['synopsis'] ?? null),
            'season'         => $animeLink->season        ?? ($jikanData['season'] ?? null),
            'year'           => $animeLink->year          ?? ($jikanData['year'] ?? null),
            'type'           => $animeLink->type          ?? ($jikanData['type'] ?? null),
            'status'         => $jikanData['status'] ?? ($animeLink->status ?? 'Unknown'),
            'studios'        => $jikanData['studios'] ?? [],
            'genres'         => $genres,
            'episodes'       => $episodes,
            'duration'       => $animeLink->duration ?? ($jikanData['duration'] ?? null),
            'aired'          => $jikanData['aired'] ?? [],
            'score'          => $animeLink->mal_score ?? ($jikanData['score'] ?? null),
            'imdb_score'     => $animeLink->imdb_score ?? (is_numeric($omdbData['imdbRating'] ?? null) ? (float) $omdbData['imdbRating'] : null),
            'imdb_id'        => $animeLink->imdb_id ?? $imdbId,
        ];

        return view('anime.show', [
            'animeLink'     => $animeLink,
            'anime'         => $animeData,
            'downloadLinks' => $downloadLinks,
            'similarAnime'  => [],
            'fromDatabase'  => $fromDatabase,
        ]);
    }

    public function rate(\Illuminate\Http\Request $request, $mal_id)
    {
        $request->validate([
            'rating' => 'required|integer|min:1|max:10',
        ]);

        $animeLink = AnimeLink::where('mal_id', $mal_id)->firstOrFail();

        \App\Models\AnimeRating::updateOrCreate(
            [
                'anime_link_id' => $animeLink->id,
                'user_id' => auth()->id(),
            ],
            [
                'rating' => $request->rating,
            ]
        );

        // Refresh from DB
        $animeLink->load('ratings');

        return response()->json([
            'success' => true,
            'average' => number_format($animeLink->average_rating, 1),
            'count' => $animeLink->ratings()->count(),
            'message' => 'تم حفظ التقييم بنجاح!',
        ]);
    }

    protected function updateScoresFromApi(AnimeLink $animeLink)
    {
        $response = Http::get("https://api.jikan.moe/v4/anime/{$animeLink->mal_id}");

        if ($response->successful()) {
            $data = $response->json('data');

            if (isset($data['score']) && is_numeric($data['score'])) {
                $animeLink->mal_score = (float) $data['score'];
            }

            if (empty($animeLink->episodes) && isset($data['episodes'])) {
                $animeLink->episodes = $data['episodes'];
            }

            if (!$animeLink->imdb_id && !empty($data['external_links'])) {
                foreach ($data['external_links'] as $link) {
                    if (str_contains($link['url'] ?? '', 'imdb.com/title/tt')) {
                        $animeLink->imdb_id = preg_replace(
                            '/^.*imdb\.com\/title\/(tt\d+).*$/',
                            '$1',
                            $link['url']
                        );
                        break;
                    }
                }
            }

            if ($animeLink->imdb_id) {
                $omdb = Http::get(config('services.omdb.url'), [
                    'apikey' => config('services.omdb.key'),
                    'i'      => $animeLink->imdb_id,
                ]);

                if ($omdb->ok()) {
                    $rating = $omdb->json('imdbRating');

               
                    if (is_numeric($rating)) {
                        $animeLink->imdb_score = (float) $rating;
                    }
                }
            }

            $animeLink->save();
        }
    }

    private function normalizeGenres($raw): array
    {
        if (is_null($raw)) return [];

        if (is_string($raw)) {
            return array_values(array_filter(array_map('trim', explode(',', $raw))));
        }

        if (is_array($raw)) {
            return collect($raw)
                ->map(fn ($g) => is_array($g) ? ($g['name'] ?? null) : $g)
                ->filter()
                ->values()
                ->all();
        }

        return [];
    }

    private function extractImdbIdFromJikan(array $jikanData): ?string
    {
        if (!empty($jikanData['external_links'])) {
            foreach ($jikanData['external_links'] as $link) {
                if (str_contains($link['url'] ?? '', 'imdb.com/title/tt')) {
                    return preg_replace('/^.*imdb\.com\/title\/(tt\d+).*$/', '$1', $link['url']);
                }
            }
        }

        return null;
    }
}